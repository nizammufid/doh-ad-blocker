#!/usr/bin/env python3
"""
ML Domain Classifier - Identifies ad/tracking domains using machine learning
Features: entropy, length, subdomains, keywords, TLD analysis, temporal patterns
"""

import re
import math
import pickle
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from collections import Counter
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

try:
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    from sklearn.model_selection import train_test_split, cross_val_score
    from sklearn.metrics import classification_report, accuracy_score
    from sklearn.preprocessing import StandardScaler
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning("scikit-learn not installed. ML features will be limited.")


class DomainClassifier:
    """ML-based domain classifier for ad detection"""
    
    # Known ad/tracker keywords
    AD_KEYWORDS = {
        'ad', 'ads', 'adv', 'adserver', 'adservice', 'adsystem', 'advertise',
        'advertisement', 'advertising', 'doubleclick', 'analytics', 'tracking',
        'tracker', 'track', 'telemetry', 'metrics', 'stats', 'beacon', 'pixel',
        'tag', 'tags', 'tagmanager', 'collect', 'collector', 'monitor', 'click',
        'clicks', 'impression', 'banner', 'popup', 'sponsored', 'promo', 'marketing',
        'conversion', 'affiliate', 'partners', 'syndication', 'content-delivery',
        'cdn-cgi', 'pagead', 'adsense', 'admob', 'inmobi', 'applovin', 'unity3d'
    }
    
    # Suspicious TLDs (commonly used by ad networks)
    SUSPICIOUS_TLDS = {
        'tk', 'ml', 'ga', 'cf', 'gq', 'top', 'xyz', 'club', 'work', 'date',
        'racing', 'loan', 'download', 'bid', 'click', 'stream', 'review'
    }
    
    # YouTube-specific patterns
    YOUTUBE_AD_PATTERNS = {
        'googlevideo': re.compile(r'r\d+---[a-z0-9-]+\.googlevideo\.com'),
        'doubleclick': re.compile(r'.*doubleclick\.net'),
        'googleadservices': re.compile(r'.*googleadservices\.com'),
        'googlesyndication': re.compile(r'.*googlesyndication\.com'),
        'googletagmanager': re.compile(r'.*googletagmanager\.com'),
        'youtube_tracking': re.compile(r'.*(ptracking|pagead).*youtube\.com'),
    }
    
    def __init__(self, model_type: str = "random_forest"):
        self.model_type = model_type
        self.model = None
        self.scaler = StandardScaler() if SKLEARN_AVAILABLE else None
        self.feature_names = []
        self.is_trained = False
    
    def extract_features(self, domain: str, query_data: Optional[Dict] = None) -> np.ndarray:
        """Extract features from a domain for ML classification"""
        features = []
        
        # Basic domain features
        features.append(len(domain))  # Domain length
        features.append(domain.count('.'))  # Subdomain count
        features.append(self._calculate_entropy(domain))  # Entropy
        features.append(int(bool(re.search(r'\d', domain))))  # Has numbers
        features.append(int(bool(re.search(r'-', domain))))  # Has hyphens
        
        # Keyword matching
        domain_lower = domain.lower()
        keyword_count = sum(1 for kw in self.AD_KEYWORDS if kw in domain_lower)
        features.append(keyword_count)  # Number of ad keywords
        features.append(int(keyword_count > 0))  # Has ad keywords (binary)
        
        # TLD analysis
        tld = domain.split('.')[-1] if '.' in domain else ''
        features.append(int(tld in self.SUSPICIOUS_TLDS))  # Suspicious TLD
        features.append(len(tld))  # TLD length
        
        # Subdomain analysis
        parts = domain.split('.')
        if len(parts) > 2:
            subdomain = parts[0]
            features.append(len(subdomain))  # Subdomain length
            features.append(int(subdomain.isdigit()))  # Numeric subdomain
            features.append(self._calculate_entropy(subdomain))  # Subdomain entropy
        else:
            features.extend([0, 0, 0])
        
        # Pattern matching scores
        features.append(self._check_youtube_ad_patterns(domain))  # YouTube ad score
        features.append(self._calculate_randomness_score(domain))  # Randomness score
        
        # Query-based features (if available)
        if query_data:
            features.append(query_data.get('count', 0))  # Query frequency
            features.append(query_data.get('unique_clients', 0))  # Unique clients
            features.append(self._calculate_temporal_score(query_data.get('timestamps', [])))  # Temporal pattern
            features.append(int(query_data.get('blocked', False)))  # Previously blocked
        else:
            features.extend([0, 0, 0, 0])
        
        return np.array(features)
    
    def _calculate_entropy(self, s: str) -> float:
        """Calculate Shannon entropy of a string"""
        if not s:
            return 0.0
        
        prob = [s.count(c) / len(s) for c in set(s)]
        entropy = -sum(p * math.log2(p) for p in prob if p > 0)
        return entropy
    
    def _calculate_randomness_score(self, domain: str) -> float:
        """Score how random/generated a domain looks"""
        score = 0.0
        
        # Check for repeating patterns
        if re.search(r'(.{2,})\1{2,}', domain):
            score += 0.5
        
        # Check for hex-like patterns
        if re.search(r'[a-f0-9]{8,}', domain):
            score += 0.3
        
        # Check for high consonant-vowel ratio
        consonants = len(re.findall(r'[bcdfghjklmnpqrstvwxyz]', domain.lower()))
        vowels = len(re.findall(r'[aeiou]', domain.lower()))
        if vowels > 0 and consonants / vowels > 3:
            score += 0.2
        
        return min(score, 1.0)
    
    def _check_youtube_ad_patterns(self, domain: str) -> float:
        """Check if domain matches YouTube ad patterns (0.0 to 1.0)"""
        score = 0.0
        
        for pattern_name, pattern in self.YOUTUBE_AD_PATTERNS.items():
            if pattern.match(domain):
                score += 0.3
        
        return min(score, 1.0)
    
    def _calculate_temporal_score(self, timestamps: List[datetime]) -> float:
        """Analyze temporal patterns (bursty vs steady)"""
        if len(timestamps) < 2:
            return 0.0
        
        # Calculate intervals between queries
        sorted_times = sorted(timestamps)
        intervals = [(sorted_times[i+1] - sorted_times[i]).total_seconds() 
                     for i in range(len(sorted_times)-1)]
        
        if not intervals:
            return 0.0
        
        # High variance = bursty (more likely ads)
        # Low variance = steady (more likely legitimate traffic)
        mean_interval = np.mean(intervals)
        if mean_interval == 0:
            return 0.0
        
        variance = np.var(intervals)
        cv = np.sqrt(variance) / mean_interval  # Coefficient of variation
        
        return min(cv / 10, 1.0)  # Normalize
    
    def train(self, known_ads: List[str], known_safe: List[str], 
              query_data: Optional[Dict] = None) -> Dict:
        """Train the ML model"""
        if not SKLEARN_AVAILABLE:
            logger.error("scikit-learn not available. Cannot train ML model.")
            return {"error": "scikit-learn not installed"}
        
        logger.info(f"Training with {len(known_ads)} ad domains and {len(known_safe)} safe domains")
        
        # Extract features
        X_ads = [self.extract_features(d, query_data.get(d) if query_data else None) 
                 for d in known_ads]
        X_safe = [self.extract_features(d, query_data.get(d) if query_data else None) 
                  for d in known_safe]
        
        X = np.array(X_ads + X_safe)
        y = np.array([1] * len(known_ads) + [0] * len(known_safe))
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train model
        if self.model_type == "random_forest":
            self.model = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                min_samples_split=5,
                random_state=42,
                n_jobs=-1
            )
        elif self.model_type == "gradient_boosting":
            self.model = GradientBoostingClassifier(
                n_estimators=100,
                learning_rate=0.1,
                max_depth=5,
                random_state=42
            )
        else:
            raise ValueError(f"Unsupported model type: {self.model_type}")
        
        logger.info("Training model...")
        self.model.fit(X_train_scaled, y_train)
        
        # Evaluate
        y_pred = self.model.predict(X_test_scaled)
        accuracy = accuracy_score(y_test, y_pred)
        
        # Cross-validation
        cv_scores = cross_val_score(self.model, X_train_scaled, y_train, cv=5)
        
        self.is_trained = True
        
        results = {
            "accuracy": accuracy,
            "cv_mean": cv_scores.mean(),
            "cv_std": cv_scores.std(),
            "classification_report": classification_report(y_test, y_pred),
            "feature_importance": self._get_feature_importance()
        }
        
        logger.info(f"Model trained successfully. Accuracy: {accuracy:.2%}")
        return results
    
    def predict(self, domain: str, query_data: Optional[Dict] = None) -> Tuple[bool, float]:
        """Predict if domain is an ad (returns: is_ad, confidence)"""
        if not self.is_trained:
            # Fallback to rule-based classification
            return self._rule_based_classify(domain, query_data)
        
        features = self.extract_features(domain, query_data)
        features_scaled = self.scaler.transform(features.reshape(1, -1))
        
        prediction = self.model.predict(features_scaled)[0]
        confidence = self.model.predict_proba(features_scaled)[0][1]  # Probability of being ad
        
        return bool(prediction), confidence
    
    def _rule_based_classify(self, domain: str, query_data: Optional[Dict] = None) -> Tuple[bool, float]:
        """Fallback rule-based classification when ML is unavailable"""
        score = 0.0
        
        domain_lower = domain.lower()
        
        # Check keywords
        keyword_matches = sum(1 for kw in self.AD_KEYWORDS if kw in domain_lower)
        score += min(keyword_matches * 0.2, 0.6)
        
        # Check YouTube patterns
        youtube_score = self._check_youtube_ad_patterns(domain)
        score += youtube_score * 0.3
        
        # Check suspicious TLD
        tld = domain.split('.')[-1] if '.' in domain else ''
        if tld in self.SUSPICIOUS_TLDS:
            score += 0.1
        
        # Check if previously blocked
        if query_data and query_data.get('blocked'):
            score += 0.3
        
        # Check randomness
        randomness = self._calculate_randomness_score(domain)
        score += randomness * 0.2
        
        is_ad = score >= 0.5
        confidence = min(score, 1.0)
        
        return is_ad, confidence
    
    def _get_feature_importance(self) -> Dict[str, float]:
        """Get feature importance from trained model"""
        if not hasattr(self.model, 'feature_importances_'):
            return {}
        
        feature_names = [
            'domain_length', 'subdomain_count', 'entropy', 'has_numbers', 'has_hyphens',
            'keyword_count', 'has_keywords', 'suspicious_tld', 'tld_length',
            'subdomain_length', 'numeric_subdomain', 'subdomain_entropy',
            'youtube_ad_score', 'randomness_score',
            'query_frequency', 'unique_clients', 'temporal_score', 'previously_blocked'
        ]
        
        importance = dict(zip(feature_names, self.model.feature_importances_))
        return dict(sorted(importance.items(), key=lambda x: x[1], reverse=True))
    
    def save_model(self, path: str):
        """Save trained model to disk"""
        model_data = {
            'model': self.model,
            'scaler': self.scaler,
            'model_type': self.model_type,
            'is_trained': self.is_trained
        }
        
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'wb') as f:
            pickle.dump(model_data, f)
        
        logger.info(f"Model saved to {path}")
    
    def load_model(self, path: str):
        """Load trained model from disk"""
        with open(path, 'rb') as f:
            model_data = pickle.load(f)
        
        self.model = model_data['model']
        self.scaler = model_data['scaler']
        self.model_type = model_data['model_type']
        self.is_trained = model_data['is_trained']
        
        logger.info(f"Model loaded from {path}")


if __name__ == "__main__":
    # Quick test
    logging.basicConfig(level=logging.INFO)
    
    classifier = DomainClassifier()
    
    # Test domains
    test_domains = [
        "ads.google.com",
        "google.com",
        "r5---sn-5hne6nsr.googlevideo.com",
        "youtube.com",
        "pagead2.googlesyndication.com",
        "wikipedia.org"
    ]
    
    print("\nRule-based classification test:")
    for domain in test_domains:
        is_ad, confidence = classifier.predict(domain)
        print(f"{domain:50s} -> {'AD' if is_ad else 'SAFE':5s} ({confidence:.2%})")
