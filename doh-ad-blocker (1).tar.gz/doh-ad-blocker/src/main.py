#!/usr/bin/env python3
"""
DoH Ad Blocker - Main Automation Script
Parses DoH logs, trains ML model, identifies new ad domains, and updates GitHub blocklists
"""

import sys
import yaml
import logging
import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Set
import requests
from collections import defaultdict

# Import our modules
from log_parser import LogParser
from ml_classifier import DomainClassifier


class DoHAdBlocker:
    """Main automation orchestrator"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        self.config = self._load_config(config_path)
        self._setup_logging()
        
        self.log_parser = LogParser(self.config['doh_logs']['format'])
        self.classifier = DomainClassifier(self.config['ml']['model_type'])
        
        self.known_ads = set()
        self.known_safe = set()
        self.whitelist = set(self.config['blocklist'].get('whitelist', []))
        
        logger.info("DoH Ad Blocker initialized")
    
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file"""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def _setup_logging(self):
        """Setup logging configuration"""
        log_config = self.config.get('logging', {})
        log_level = getattr(logging, log_config.get('level', 'INFO'))
        log_file = log_config.get('file', 'logs/doh-blocker.log')
        
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        global logger
        logger = logging.getLogger(__name__)
    
    def load_training_data(self):
        """Load known ad and safe domains for training"""
        logger.info("Loading training data...")
        
        # Load known ads
        ad_file = self.config['ml']['known_ad_domains']
        if Path(ad_file).exists():
            with open(ad_file, 'r') as f:
                self.known_ads = {line.strip() for line in f if line.strip()}
            logger.info(f"Loaded {len(self.known_ads)} known ad domains")
        else:
            logger.warning(f"Known ad domains file not found: {ad_file}")
            # Download default blocklist
            self._download_default_blocklists()
        
        # Load known safe domains
        safe_file = self.config['ml']['known_safe_domains']
        if Path(safe_file).exists():
            with open(safe_file, 'r') as f:
                self.known_safe = {line.strip() for line in f if line.strip()}
            logger.info(f"Loaded {len(self.known_safe)} known safe domains")
        else:
            logger.warning(f"Known safe domains file not found: {safe_file}")
            # Use some common safe domains as defaults
            self.known_safe = {
                'google.com', 'youtube.com', 'facebook.com', 'amazon.com',
                'wikipedia.org', 'reddit.com', 'twitter.com', 'github.com',
                'stackoverflow.com', 'linkedin.com', 'microsoft.com', 'apple.com'
            }
    
    def _download_default_blocklists(self):
        """Download default blocklists as training data"""
        logger.info("Downloading default blocklists...")
        
        blocklist_urls = self.config['blocklist'].get('merge_with', [])
        
        for url in blocklist_urls:
            try:
                logger.info(f"Downloading {url}")
                response = requests.get(url, timeout=30)
                response.raise_for_status()
                
                # Parse domains from various formats
                for line in response.text.split('\n'):
                    line = line.strip()
                    
                    # Skip comments and empty lines
                    if not line or line.startswith('#'):
                        continue
                    
                    # Extract domain
                    if line.startswith('0.0.0.0') or line.startswith('127.0.0.1'):
                        parts = line.split()
                        if len(parts) >= 2:
                            domain = parts[1]
                            self.known_ads.add(domain)
                    elif line.startswith('||') or line.startswith('@@||'):
                        # AdBlock format
                        domain = line.replace('||', '').replace('@@||', '').split('^')[0].split('/')[0]
                        self.known_ads.add(domain)
                    else:
                        # Plain domain list
                        self.known_ads.add(line)
                
                logger.info(f"Downloaded {url}")
            
            except Exception as e:
                logger.error(f"Failed to download {url}: {e}")
        
        # Save to file
        ad_file = self.config['ml']['known_ad_domains']
        Path(ad_file).parent.mkdir(parents=True, exist_ok=True)
        with open(ad_file, 'w') as f:
            f.write('\n'.join(sorted(self.known_ads)))
        
        logger.info(f"Saved {len(self.known_ads)} domains to {ad_file}")
    
    def parse_logs(self) -> Dict:
        """Parse DoH logs and extract query statistics"""
        logger.info("Parsing DoH logs...")
        
        log_paths = self.config['doh_logs']['log_paths']
        days = self.config['doh_logs']['analysis_window_days']
        
        stats = self.log_parser.parse_logs(log_paths, days)
        
        logger.info(f"Parsed {stats['total_queries']} queries from {stats['total_domains']} unique domains")
        return stats
    
    def train_model(self, query_stats: Dict):
        """Train or retrain the ML model"""
        logger.info("Training ML model...")
        
        # Check if model exists and is recent
        model_path = "models/classifier.pkl"
        retrain_interval = self.config['ml']['retrain_interval_days']
        
        if Path(model_path).exists():
            model_age = (datetime.now() - datetime.fromtimestamp(Path(model_path).stat().st_mtime)).days
            if model_age < retrain_interval:
                logger.info(f"Model is only {model_age} days old. Loading existing model.")
                self.classifier.load_model(model_path)
                return
        
        # Train new model
        results = self.classifier.train(
            list(self.known_ads),
            list(self.known_safe),
            query_stats['domains']
        )
        
        logger.info(f"Model training completed:")
        logger.info(f"  Accuracy: {results['accuracy']:.2%}")
        logger.info(f"  CV Score: {results['cv_mean']:.2%} (+/- {results['cv_std']:.2%})")
        
        # Save model
        self.classifier.save_model(model_path)
        
        # Log feature importance
        logger.info("Top feature importances:")
        for feature, importance in list(results['feature_importance'].items())[:5]:
            logger.info(f"  {feature}: {importance:.4f}")
    
    def identify_new_ads(self, query_stats: Dict) -> List[Dict]:
        """Identify new ad domains from parsed logs"""
        logger.info("Classifying domains...")
        
        min_count = self.config['doh_logs']['min_query_count']
        confidence_threshold = self.config['ml']['confidence_threshold']
        manual_review_threshold = self.config['validation']['manual_review_threshold']
        
        new_ads = []
        manual_review = []
        
        for domain, data in query_stats['domains'].items():
            # Skip if below minimum query count
            if data['count'] < min_count:
                continue
            
            # Skip if already in known ads
            if domain in self.known_ads:
                continue
            
            # Skip whitelisted domains
            if self._is_whitelisted(domain):
                continue
            
            # Classify
            is_ad, confidence = self.classifier.predict(domain, data)
            
            if is_ad:
                entry = {
                    'domain': domain,
                    'confidence': confidence,
                    'query_count': data['count'],
                    'unique_clients': data['unique_clients'],
                    'first_seen': data['first_seen'].isoformat() if data['first_seen'] else None,
                    'last_seen': data['last_seen'].isoformat() if data['last_seen'] else None
                }
                
                if confidence >= confidence_threshold:
                    new_ads.append(entry)
                elif confidence >= manual_review_threshold:
                    manual_review.append(entry)
        
        logger.info(f"Identified {len(new_ads)} new ad domains (high confidence)")
        logger.info(f"Flagged {len(manual_review)} domains for manual review")
        
        # Save manual review list
        if manual_review and self.config['validation']['enabled']:
            review_file = self.config['validation']['review_output']
            Path(review_file).parent.mkdir(parents=True, exist_ok=True)
            with open(review_file, 'w') as f:
                f.write("# Domains flagged for manual review\n")
                f.write("# Format: domain | confidence | query_count\n\n")
                for entry in sorted(manual_review, key=lambda x: x['confidence'], reverse=True):
                    f.write(f"{entry['domain']:50s} | {entry['confidence']:.2%} | {entry['query_count']}\n")
            
            logger.info(f"Manual review list saved to {review_file}")
        
        return new_ads
    
    def _is_whitelisted(self, domain: str) -> bool:
        """Check if domain is whitelisted"""
        # Exact match
        if domain in self.whitelist:
            return True
        
        # Check if subdomain of whitelisted domain
        for whitelisted in self.whitelist:
            if domain.endswith('.' + whitelisted):
                return True
        
        return False
    
    def apply_youtube_filters(self, new_ads: List[Dict]) -> List[Dict]:
        """Apply YouTube-specific filtering"""
        if not self.config['youtube']['enabled']:
            return new_ads
        
        logger.info("Applying YouTube-specific filters...")
        
        force_block = self.config['youtube']['force_block']
        youtube_ads = []
        
        for domain in force_block:
            # Handle wildcards
            if '*' in domain:
                pattern = domain.replace('*', '.*')
                matching = [entry for entry in new_ads 
                           if __import__('re').match(pattern, entry['domain'])]
                youtube_ads.extend(matching)
            else:
                if domain not in [entry['domain'] for entry in new_ads]:
                    youtube_ads.append({
                        'domain': domain,
                        'confidence': 1.0,
                        'query_count': 0,
                        'unique_clients': 0,
                        'source': 'youtube_force_block'
                    })
        
        # Merge and deduplicate
        all_domains = {entry['domain'] for entry in new_ads}
        for yt_entry in youtube_ads:
            if yt_entry['domain'] not in all_domains:
                new_ads.append(yt_entry)
        
        logger.info(f"Added {len(youtube_ads)} YouTube-specific domains")
        return new_ads
    
    def generate_blocklists(self, new_ads: List[Dict]) -> Dict[str, str]:
        """Generate blocklists in various formats"""
        logger.info("Generating blocklists...")
        
        # Merge with existing known ads
        all_ads = self.known_ads.copy()
        all_ads.update(entry['domain'] for entry in new_ads)
        
        output_dir = Path(self.config['blocklist']['output_dir'])
        output_dir.mkdir(parents=True, exist_ok=True)
        
        formats = self.config['blocklist']['output_formats']
        filenames = self.config['blocklist']['filenames']
        
        generated_files = {}
        
        # Generate hosts format
        if 'hosts' in formats:
            hosts_file = output_dir / filenames['hosts']
            with open(hosts_file, 'w') as f:
                f.write(f"# DoH Ad Blocker - Generated on {datetime.now().isoformat()}\n")
                f.write(f"# Total domains: {len(all_ads)}\n\n")
                for domain in sorted(all_ads):
                    f.write(f"0.0.0.0 {domain}\n")
            generated_files['hosts'] = str(hosts_file)
            logger.info(f"Generated hosts file: {hosts_file}")
        
        # Generate plain domain list
        if 'domains' in formats:
            domains_file = output_dir / filenames['domains']
            with open(domains_file, 'w') as f:
                f.write(f"# DoH Ad Blocker - Generated on {datetime.now().isoformat()}\n")
                f.write(f"# Total domains: {len(all_ads)}\n\n")
                for domain in sorted(all_ads):
                    f.write(f"{domain}\n")
            generated_files['domains'] = str(domains_file)
            logger.info(f"Generated domains file: {domains_file}")
        
        # Generate AdBlock format
        if 'adblock' in formats:
            adblock_file = output_dir / filenames['adblock']
            with open(adblock_file, 'w') as f:
                f.write(f"! DoH Ad Blocker - Generated on {datetime.now().isoformat()}\n")
                f.write(f"! Total domains: {len(all_ads)}\n\n")
                for domain in sorted(all_ads):
                    f.write(f"||{domain}^\n")
            generated_files['adblock'] = str(adblock_file)
            logger.info(f"Generated AdBlock file: {adblock_file}")
        
        # Generate dnsmasq format
        if 'dnsmasq' in formats:
            dnsmasq_file = output_dir / filenames['dnsmasq']
            with open(dnsmasq_file, 'w') as f:
                f.write(f"# DoH Ad Blocker - Generated on {datetime.now().isoformat()}\n")
                f.write(f"# Total domains: {len(all_ads)}\n\n")
                for domain in sorted(all_ads):
                    f.write(f"address=/{domain}/0.0.0.0\n")
            generated_files['dnsmasq'] = str(dnsmasq_file)
            logger.info(f"Generated dnsmasq file: {dnsmasq_file}")
        
        # Generate Unbound format
        if 'unbound' in formats:
            unbound_file = output_dir / filenames['unbound']
            with open(unbound_file, 'w') as f:
                f.write(f"# DoH Ad Blocker - Generated on {datetime.now().isoformat()}\n")
                f.write(f"# Total domains: {len(all_ads)}\n\n")
                for domain in sorted(all_ads):
                    f.write(f'local-zone: "{domain}" static\n')
            generated_files['unbound'] = str(unbound_file)
            logger.info(f"Generated Unbound file: {unbound_file}")
        
        return generated_files
    
    def push_to_github(self, new_ads: List[Dict], generated_files: Dict[str, str]):
        """Push updated blocklists to GitHub"""
        logger.info("Pushing updates to GitHub...")
        
        # This is a placeholder - actual implementation would use GitPython or subprocess
        # For security, we'll create a bash script instead
        
        github_config = self.config['github']
        
        script_content = f"""#!/bin/bash
# Auto-generated GitHub push script

cd {Path.cwd()}

# Add files
git add {' '.join(generated_files.values())}

# Commit
git commit -m "{github_config['commit_message'].format(
    date=datetime.now().strftime('%Y-%m-%d'),
    count=len(new_ads)
)}"

# Push
git push origin {github_config['branch']}

echo "Successfully pushed to GitHub!"
"""
        
        script_path = Path("scripts/push_to_github.sh")
        script_path.parent.mkdir(parents=True, exist_ok=True)
        script_path.write_text(script_content)
        script_path.chmod(0o755)
        
        logger.info(f"GitHub push script created: {script_path}")
        logger.info("Run this script to push updates to GitHub")
        logger.info(f"  bash {script_path}")
    
    def run(self):
        """Main execution flow"""
        logger.info("=" * 80)
        logger.info("DoH Ad Blocker - Starting automated run")
        logger.info("=" * 80)
        
        try:
            # Step 1: Load training data
            self.load_training_data()
            
            # Step 2: Parse logs
            query_stats = self.parse_logs()
            
            # Step 3: Train/load model
            self.train_model(query_stats)
            
            # Step 4: Identify new ad domains
            new_ads = self.identify_new_ads(query_stats)
            
            # Step 5: Apply YouTube filters
            new_ads = self.apply_youtube_filters(new_ads)
            
            # Step 6: Generate blocklists
            generated_files = self.generate_blocklists(new_ads)
            
            # Step 7: Push to GitHub
            if new_ads:
                self.push_to_github(new_ads, generated_files)
            else:
                logger.info("No new domains to push")
            
            logger.info("=" * 80)
            logger.info("DoH Ad Blocker - Completed successfully")
            logger.info(f"New domains identified: {len(new_ads)}")
            logger.info("=" * 80)
        
        except Exception as e:
            logger.error(f"Error during execution: {e}", exc_info=True)
            raise


def main():
    parser = argparse.ArgumentParser(description="DoH Ad Blocker - Automated blocklist updater")
    parser.add_argument('--config', default='config/config.yaml', help='Config file path')
    parser.add_argument('--dry-run', action='store_true', help='Run without pushing to GitHub')
    
    args = parser.parse_args()
    
    blocker = DoHAdBlocker(args.config)
    blocker.run()


if __name__ == "__main__":
    main()
