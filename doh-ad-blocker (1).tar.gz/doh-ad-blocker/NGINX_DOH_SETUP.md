# Nginx DoH (DNS-over-HTTPS) Integration Guide

## Overview

This guide shows how to configure nginx as a DoH upstream proxy and log DNS queries for the DoH Ad Blocker to analyze.

## Architecture

```
Client (Browser/App)
    ↓ HTTPS (DoH)
Nginx (443) → logs DNS queries
    ↓ DNS/DoT
Upstream DNS (Unbound/Pi-hole/etc)
    ↓
DoH Ad Blocker → analyzes logs → updates blocklists
```

## Nginx Configuration

### Option 1: Nginx with DNS Module (Recommended)

Requires nginx compiled with `--with-stream` and DNS resolution support.

#### /etc/nginx/nginx.conf

```nginx
# Load DNS module
load_module modules/ngx_stream_module.so;

# DNS upstream servers
upstream dns_upstream {
    # Use your local DNS server
    server 127.0.0.1:53;
    # Or Pi-hole
    # server 127.0.0.1:5335;
    # Or Unbound
    # server 127.0.0.1:5353;
}

# HTTP/2 server for DoH
server {
    listen 443 ssl http2;
    server_name doh.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/doh.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/doh.yourdomain.com/privkey.pem;

    # DoH endpoint
    location /dns-query {
        # Enable DNS over HTTPS
        proxy_pass http://dns_upstream;
        
        # Important: Pass through DNS query
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        
        # Log DNS queries with custom format
        access_log /var/log/nginx/doh-access.log doh_format;
        error_log /var/log/nginx/doh-error.log;
        
        # CORS headers (optional, for browser access)
        add_header Access-Control-Allow-Origin *;
        add_header Access-Control-Allow-Methods "GET, POST, OPTIONS";
    }
}

# Custom log format that includes DNS query info
log_format doh_format '$remote_addr - $remote_user [$time_local] '
                      '"$request" $status $body_bytes_sent '
                      '"$http_referer" "$http_user_agent" '
                      '"$dns_qname" "$dns_qtype"';
```

### Option 2: Nginx with DNS Proxy Module (Advanced)

Using `nginx-module-dns` or `doh-proxy`:

#### /etc/nginx/sites-available/doh

```nginx
server {
    listen 443 ssl http2;
    server_name doh.yourdomain.com;

    ssl_certificate /etc/ssl/certs/doh.crt;
    ssl_certificate_key /etc/ssl/private/doh.key;

    # DoH endpoint
    location /dns-query {
        # Proxy to dns-over-https proxy
        proxy_pass http://127.0.0.1:8053;
        
        # Custom logging with DNS query extraction
        access_log /var/log/nginx/doh-queries.log doh_json;
        
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Real-IP $remote_addr;
    }
}

# JSON log format (easier to parse)
log_format doh_json escape=json
    '{'
        '"time":"$time_iso8601",'
        '"remote_addr":"$remote_addr",'
        '"request":"$request",'
        '"status":$status,'
        '"body_bytes_sent":$body_bytes_sent,'
        '"http_user_agent":"$http_user_agent",'
        '"dns_qname":"$arg_dns",'
        '"dns_qtype":"$arg_type"'
    '}';
```

### Option 3: Using dns-over-https Proxy with Nginx Frontend

Install [m13253/dns-over-https](https://github.com/m13253/dns-over-https):

```bash
# Install doh-server
git clone https://github.com/m13253/dns-over-https.git
cd dns-over-https
make

# Configure doh-server
sudo cp doh-server/doh-server /usr/local/bin/
```

#### /etc/dns-over-https/doh-server.conf

```toml
listen = [
    "127.0.0.1:8053",
]

[upstream]
upstream = [
    "udp:127.0.0.1:53",
]

[upstream.timeout]
query_timeout = 10

[log]
file = "/var/log/doh-server/queries.log"
level = "info"
```

#### Nginx config to proxy to doh-server

```nginx
server {
    listen 443 ssl http2;
    server_name doh.yourdomain.com;

    ssl_certificate /etc/ssl/certs/doh.crt;
    ssl_certificate_key /etc/ssl/private/doh.key;

    location /dns-query {
        proxy_pass http://127.0.0.1:8053/dns-query;
        
        # Log all requests
        access_log /var/log/nginx/doh-access.log combined;
        
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Extracting DNS Queries from DoH Requests

### Method 1: Parse HTTP POST Body (Advanced)

DoH queries are base64-encoded DNS wire format in POST body. Create a lua script:

#### /etc/nginx/lua/log_dns_query.lua

```lua
local cjson = require "cjson"
local base64 = require "ngx.base64"

-- Read POST body
ngx.req.read_body()
local body = ngx.req.get_body_data()

if body then
    -- Decode base64 DNS query
    local dns_query = base64.decode_base64url(body)
    
    if dns_query then
        -- Parse DNS query (simplified)
        -- Extract domain name from DNS wire format
        local domain = parse_dns_domain(dns_query)
        
        -- Log to custom file
        local log_file = io.open("/var/log/nginx/dns-queries.log", "a")
        log_file:write(string.format("%s %s %s\n", 
            os.date("%Y-%m-%d %H:%M:%S"),
            ngx.var.remote_addr,
            domain))
        log_file:close()
    end
end
```

### Method 2: Use Query Parameters (GET requests)

Some DoH implementations support GET with query parameters:

```nginx
location /dns-query {
    # GET /dns-query?dns=... format
    
    # Extract DNS query from parameter
    set $dns_query $arg_dns;
    
    # Custom log format
    access_log /var/log/nginx/doh-queries.log doh_get;
    
    proxy_pass http://127.0.0.1:8053;
}

log_format doh_get '$remote_addr [$time_local] dns=$dns_query';
```

### Method 3: Upstream DNS Server Logging (Easiest)

Let your upstream DNS server (Pi-hole, Unbound) do the logging:

```nginx
# Nginx just proxies, upstream logs
location /dns-query {
    proxy_pass http://127.0.0.1:8053;
    access_log off;  # Don't log in nginx
}
```

Then configure DoH Ad Blocker to read from Pi-hole/Unbound logs instead.

## DoH Ad Blocker Configuration

### For Nginx Custom Logs

Edit `config/config.yaml`:

```yaml
doh_logs:
  format: "nginx_doh"
  log_paths:
    - "/var/log/nginx/doh-access.log"
    - "/var/log/nginx/doh-access.log.1"
  
  # Optional: specify your custom log format
  nginx_log_format: '$remote_addr - $remote_user [$time_local] "$request" $status $body_bytes_sent "$http_referer" "$http_user_agent" "$dns_qname" "$dns_qtype"'
```

### For JSON Logs

```yaml
doh_logs:
  format: "nginx_doh"
  log_paths:
    - "/var/log/nginx/doh-queries.log"
```

The parser automatically detects JSON format.

### For Upstream Pi-hole Logs

```yaml
doh_logs:
  format: "pihole"
  log_paths:
    - "/var/log/pihole/pihole.log"
```

## Complete Setup Example

### 1. Install Required Software

```bash
# Install nginx with stream module
sudo apt update
sudo apt install nginx-full certbot python3-certbot-nginx

# Install doh-server (optional)
sudo apt install golang-go
git clone https://github.com/m13253/dns-over-https.git
cd dns-over-https && make
sudo cp doh-server/doh-server /usr/local/bin/
```

### 2. Setup SSL Certificate

```bash
sudo certbot --nginx -d doh.yourdomain.com
```

### 3. Configure Nginx

```bash
sudo nano /etc/nginx/sites-available/doh
# Paste configuration from above

sudo ln -s /etc/nginx/sites-available/doh /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 4. Configure DoH Ad Blocker

```bash
cd doh-ad-blocker
nano config/config.yaml
# Set format: "nginx_doh"
# Set log_paths: ["/var/log/nginx/doh-access.log"]
```

### 5. Test It

```bash
# Test DoH endpoint
curl -H "accept: application/dns-message" \
     "https://doh.yourdomain.com/dns-query?dns=AAABAAABAAAAAAAAA3d3dwdleGFtcGxlA2NvbQAAAQAB"

# Check logs
tail -f /var/log/nginx/doh-access.log

# Run DoH Ad Blocker
source venv/bin/activate
python src/main.py
```

## Log Rotation

Ensure nginx logs rotate properly:

#### /etc/logrotate.d/nginx-doh

```
/var/log/nginx/doh-*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data adm
    sharedscripts
    postrotate
        if [ -f /var/run/nginx.pid ]; then
            kill -USR1 `cat /var/run/nginx.pid`
        fi
    endscript
}
```

## Security Considerations

1. **Rate Limiting**: Prevent abuse
```nginx
limit_req_zone $binary_remote_addr zone=doh:10m rate=10r/s;

location /dns-query {
    limit_req zone=doh burst=20;
    # ...
}
```

2. **Access Control**: Restrict to your network
```nginx
location /dns-query {
    allow 192.168.1.0/24;
    deny all;
    # ...
}
```

3. **DNSSEC**: Enable on upstream
```nginx
upstream dns_upstream {
    server 127.0.0.1:53;  # Ensure this supports DNSSEC
}
```

## Troubleshooting

### Logs show no DNS queries

**Problem**: Nginx logs requests but no domain names

**Solution**: 
- Ensure you're using custom log format with DNS variables
- Or parse upstream DNS server logs instead
- Consider using doh-server which logs queries

### DoH Ad Blocker can't parse logs

**Problem**: Parser errors

**Solution**:
```bash
# Test the log format
python -c "
from src.log_parser import LogParser
parser = LogParser('nginx_doh')
stats = parser.parse_logs(['/var/log/nginx/doh-access.log'], days=1)
print(stats)
"
```

### DNS queries not being resolved

**Problem**: DoH endpoint returns errors

**Solution**:
- Check upstream DNS is accessible: `dig @127.0.0.1 google.com`
- Check nginx error logs: `tail -f /var/log/nginx/doh-error.log`
- Verify SSL certificate is valid

## Alternative: Skip Nginx Parsing

If parsing nginx logs is too complex, use this simpler approach:

```yaml
# Configure DoH Ad Blocker to read from Pi-hole/Unbound directly
doh_logs:
  format: "pihole"  # or "unbound"
  log_paths:
    - "/var/log/pihole/pihole.log"

# Nginx just proxies to Pi-hole DoH
# No need to parse nginx logs
```

Your Pi-hole logs all queries, nginx just handles HTTPS.

## Resources

- [RFC 8484 - DNS Queries over HTTPS (DoH)](https://tools.ietf.org/html/rfc8484)
- [m13253/dns-over-https](https://github.com/m13253/dns-over-https)
- [Nginx Stream Module](http://nginx.org/en/docs/stream/ngx_stream_core_module.html)
- [Pi-hole DoH Documentation](https://docs.pi-hole.net/guides/dns/cloudflared/)
