# Example Output

## Sample Run

```bash
$ python src/main.py

================================================================================
DoH Ad Blocker - Starting automated run
================================================================================

2024-03-05 02:00:01 - INFO - DoH Ad Blocker initialized
2024-03-05 02:00:01 - INFO - Loading training data...
2024-03-05 02:00:01 - INFO - Loaded 125,432 known ad domains
2024-03-05 02:00:01 - INFO - Loaded 12 known safe domains
2024-03-05 02:00:02 - INFO - Parsing DoH logs...
2024-03-05 02:00:05 - INFO - Parsed 45,823 queries from 8,234 unique domains
2024-03-05 02:00:05 - INFO - Training ML model...
2024-03-05 02:00:05 - INFO - Model is only 2 days old. Loading existing model.
2024-03-05 02:00:05 - INFO - Model loaded from models/classifier.pkl
2024-03-05 02:00:05 - INFO - Classifying domains...
2024-03-05 02:00:12 - INFO - Identified 43 new ad domains (high confidence)
2024-03-05 02:00:12 - INFO - Flagged 12 domains for manual review
2024-03-05 02:00:12 - INFO - Manual review list saved to logs/manual_review.txt
2024-03-05 02:00:12 - INFO - Applying YouTube-specific filters...
2024-03-05 02:00:12 - INFO - Added 5 YouTube-specific domains
2024-03-05 02:00:12 - INFO - Generating blocklists...
2024-03-05 02:00:13 - INFO - Generated hosts file: blocklists/hosts.txt
2024-03-05 02:00:13 - INFO - Generated domains file: blocklists/domains.txt
2024-03-05 02:00:13 - INFO - Generated AdBlock file: blocklists/adblock.txt
2024-03-05 02:00:13 - INFO - Generated dnsmasq file: blocklists/dnsmasq.conf
2024-03-05 02:00:13 - INFO - Generated Unbound file: blocklists/unbound.conf
2024-03-05 02:00:13 - INFO - Pushing updates to GitHub...
2024-03-05 02:00:13 - INFO - GitHub push script created: scripts/push_to_github.sh
2024-03-05 02:00:13 - INFO - Run this script to push updates to GitHub
2024-03-05 02:00:13 - INFO -   bash scripts/push_to_github.sh

================================================================================
DoH Ad Blocker - Completed successfully
New domains identified: 48
================================================================================
```

## Sample Classification Results

### High-Confidence Ad Domains (Auto-Added)

```
Domain                                          Confidence  Queries  Clients
--------------------------------------------------------------------------------
ad-delivery.example.com                         98.5%       145      8
tracking-pixel.adnetwork.com                    97.2%       89       12
r7---sn-4g5ednsz.googlevideo.com               96.8%       234      15
analytics-beacon.service.net                    95.3%       67       4
doubleclick-metrics.net                         94.7%       421      18
pagead-conversion.google.com                    93.2%       156      9
telemetry-ingest.mozilla.org                    91.5%       78       5
ads-serve-system.cloudfront.net                 89.4%       234      14
```

### Manual Review Required (75-85% confidence)

```
Domain                                          Confidence  Queries  Clients
--------------------------------------------------------------------------------
cdn-metrics.example.com                         82.3%       45       3
usage-stats.software.com                        79.8%       23       2
analytics.internal-tool.com                     77.5%       156      1
beacon.helpdesk-widget.io                       76.2%       34       2
```

## Generated Blocklist Statistics

```
Format          Domains     Size        Updated
--------------------------------------------------------
hosts.txt       125,480     4.2 MB      2024-03-05 02:00
domains.txt     125,480     2.8 MB      2024-03-05 02:00
adblock.txt     125,480     3.1 MB      2024-03-05 02:00
dnsmasq.conf    125,480     5.6 MB      2024-03-05 02:00
unbound.conf    125,480     6.8 MB      2024-03-05 02:00
```

## YouTube Ad Blocking Results

### Detected YouTube Ad Patterns

```
✓ Blocked: r5---sn-5hne6nsr.googlevideo.com (redirector)
✓ Blocked: doubleclick.net (ad server)
✓ Blocked: googleadservices.com (ad services)
✓ Blocked: pagead2.googlesyndication.com (syndication)
✓ Blocked: youtube.com/pagead (page ads)
✓ Blocked: youtube.com/ptracking (tracking)

✗ Allowed: googlevideo.com (required for videos)
✗ Allowed: ytimg.com (required for thumbnails)
✗ Allowed: youtube.com (main site)
```

### Estimated Blocking Coverage

- **Tracking & Analytics:** ~95% blocked
- **Ad Beacons & Pixels:** ~90% blocked
- **Pre-roll Ads (DNS-level):** ~30% blocked
- **In-video Ads:** ~0% (requires browser extension)
- **Overall YouTube Experience:** Faster loading, less tracking

## Feature Importance (from ML Model)

```
Feature                    Importance
----------------------------------------
keyword_count              0.2341
query_frequency            0.1876
subdomain_entropy          0.1423
youtube_ad_score           0.1198
has_keywords               0.0987
domain_length              0.0765
temporal_score             0.0654
randomness_score           0.0432
previously_blocked         0.0324
```

## Git Commit Message

```
🤖 Auto-update: 2024-03-05 - 48 domains

- Generated from DoH log analysis
- ML confidence threshold: 85%
- YouTube ad filtering: enabled

[skip ci]
```

## Usage in Pi-hole

Add this URL to Pi-hole Adlists:
```
https://raw.githubusercontent.com/your-username/ad-blocklists/main/blocklists/domains.txt
```

**Result:** 125,480 domains blocked across your network!
