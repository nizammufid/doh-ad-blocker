#!/usr/bin/env python3
"""
Test Script - Validates DoH Ad Blocker functionality
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from log_parser import LogParser
from ml_classifier import DomainClassifier

def test_log_parser():
    """Test log parsing functionality"""
    print("=" * 60)
    print("Testing Log Parser")
    print("=" * 60)
    
    # Create sample Pi-hole log
    sample_log = """
Jan 15 10:23:45 dnsmasq[1234]: query[A] ads.google.com from 192.168.1.100
Jan 15 10:23:46 dnsmasq[1234]: reply ads.google.com is 0.0.0.0
Jan 15 10:23:47 dnsmasq[1234]: query[A] youtube.com from 192.168.1.100
Jan 15 10:23:48 dnsmasq[1234]: reply youtube.com is 142.250.80.46
Jan 15 10:23:49 dnsmasq[1234]: query[A] doubleclick.net from 192.168.1.101
Jan 15 10:23:50 dnsmasq[1234]: reply doubleclick.net is 0.0.0.0
Jan 15 10:23:51 dnsmasq[1234]: query[A] googlevideo.com from 192.168.1.100
Jan 15 10:23:52 dnsmasq[1234]: query[A] r5---sn-5hne6nsr.googlevideo.com from 192.168.1.100
"""
    
    # Write to temp file
    temp_log = Path('/tmp/test_pihole.log')
    temp_log.write_text(sample_log)
    
    # Parse
    parser = LogParser("pihole")
    stats = parser.parse_logs([str(temp_log)], days=30)
    
    print(f"\n✓ Parsed {stats['total_queries']} queries")
    print(f"✓ Found {stats['total_domains']} unique domains")
    
    print("\nDomains detected:")
    for domain, data in stats['domains'].items():
        blocked_flag = "🚫" if data['blocked'] else "✅"
        print(f"  {blocked_flag} {domain:40s} - {data['count']} queries")
    
    # Test top domains
    top = parser.get_top_domains(5)
    print(f"\nTop 5 domains:")
    for domain, count in top:
        print(f"  {domain:40s} - {count} queries")
    
    print("\n✅ Log Parser Test PASSED\n")
    return stats


def test_ml_classifier(query_stats):
    """Test ML classifier functionality"""
    print("=" * 60)
    print("Testing ML Classifier")
    print("=" * 60)
    
    classifier = DomainClassifier()
    
    # Test domains
    test_domains = [
        ("ads.google.com", True),
        ("google.com", False),
        ("doubleclick.net", True),
        ("youtube.com", False),
        ("pagead2.googlesyndication.com", True),
        ("r5---sn-5hne6nsr.googlevideo.com", True),
        ("wikipedia.org", False),
        ("tracking.example.com", True),
        ("telemetry-xyz123.com", True),
        ("github.com", False)
    ]
    
    print("\nRule-based classification test:")
    print(f"{'Domain':<45} {'Expected':<10} {'Predicted':<10} {'Confidence':<12} {'Result'}")
    print("-" * 90)
    
    correct = 0
    total = len(test_domains)
    
    for domain, expected_ad in test_domains:
        is_ad, confidence = classifier.predict(domain, query_stats['domains'].get(domain))
        
        expected_str = "AD" if expected_ad else "SAFE"
        predicted_str = "AD" if is_ad else "SAFE"
        result = "✅" if is_ad == expected_ad else "❌"
        
        if is_ad == expected_ad:
            correct += 1
        
        print(f"{domain:<45} {expected_str:<10} {predicted_str:<10} {confidence:>6.1%}       {result}")
    
    accuracy = correct / total
    print(f"\nAccuracy: {correct}/{total} = {accuracy:.1%}")
    
    if accuracy >= 0.7:
        print("✅ ML Classifier Test PASSED\n")
    else:
        print("⚠️  ML Classifier Test - Low Accuracy\n")
    
    # Test feature extraction
    print("\nFeature extraction test:")
    features = classifier.extract_features("ads.tracking-system.example.com")
    print(f"  Domain: ads.tracking-system.example.com")
    print(f"  Features extracted: {len(features)} values")
    print(f"  Sample features: {features[:5]}")
    print("✅ Feature extraction working\n")
    
    return classifier


def test_youtube_patterns():
    """Test YouTube ad detection"""
    print("=" * 60)
    print("Testing YouTube Ad Detection")
    print("=" * 60)
    
    classifier = DomainClassifier()
    
    youtube_test_cases = [
        # (domain, should_be_detected_as_ad)
        ("r5---sn-5hne6nsr.googlevideo.com", True),
        ("googlevideo.com", False),  # Base domain should not be blocked
        ("doubleclick.net", True),
        ("pagead2.googlesyndication.com", True),
        ("youtube.com", False),
        ("s.youtube.com", False),  # Stats endpoint - debatable
        ("googleadservices.com", True),
    ]
    
    print("\nYouTube domain classification:")
    print(f"{'Domain':<45} {'Expected':<10} {'Ad Score':<10} {'Result'}")
    print("-" * 75)
    
    correct = 0
    for domain, expected_ad in youtube_test_cases:
        youtube_score = classifier._check_youtube_ad_patterns(domain)
        is_ad = youtube_score > 0.3
        
        expected_str = "AD" if expected_ad else "SAFE"
        result = "✅" if is_ad == expected_ad else "❌"
        
        if is_ad == expected_ad:
            correct += 1
        
        print(f"{domain:<45} {expected_str:<10} {youtube_score:>6.1%}     {result}")
    
    accuracy = correct / len(youtube_test_cases)
    print(f"\nYouTube Detection Accuracy: {correct}/{len(youtube_test_cases)} = {accuracy:.1%}")
    
    if accuracy >= 0.7:
        print("✅ YouTube Detection Test PASSED\n")
    else:
        print("⚠️  YouTube Detection Test - Low Accuracy\n")


def test_training():
    """Test model training"""
    print("=" * 60)
    print("Testing Model Training")
    print("=" * 60)
    
    try:
        from sklearn.ensemble import RandomForestClassifier
        
        classifier = DomainClassifier("random_forest")
        
        # Sample training data
        known_ads = [
            "ads.example.com",
            "doubleclick.net",
            "tracking.site.com",
            "ad-server.net",
            "analytics-beacon.com",
            "pagead2.googlesyndication.com"
        ]
        
        known_safe = [
            "google.com",
            "youtube.com",
            "wikipedia.org",
            "github.com",
            "stackoverflow.com",
            "reddit.com"
        ]
        
        print(f"\nTraining with {len(known_ads)} ad domains and {len(known_safe)} safe domains...")
        results = classifier.train(known_ads, known_safe)
        
        print(f"\n✓ Training completed")
        print(f"  Accuracy: {results['accuracy']:.2%}")
        print(f"  CV Score: {results['cv_mean']:.2%} (+/- {results['cv_std']:.2%})")
        
        print("\n✅ Model Training Test PASSED\n")
        
    except ImportError:
        print("\n⚠️  scikit-learn not available - skipping training test")
        print("   Install with: pip install scikit-learn\n")


def run_all_tests():
    """Run all tests"""
    print("\n" + "=" * 60)
    print(" DoH Ad Blocker - System Tests")
    print("=" * 60 + "\n")
    
    try:
        # Test 1: Log Parser
        query_stats = test_log_parser()
        
        # Test 2: ML Classifier
        classifier = test_ml_classifier(query_stats)
        
        # Test 3: YouTube Detection
        test_youtube_patterns()
        
        # Test 4: Model Training
        test_training()
        
        print("=" * 60)
        print("🎉 All Tests Completed!")
        print("=" * 60)
        print("\nSystem is ready to use. Next steps:")
        print("  1. Configure config/config.yaml")
        print("  2. Run: python src/main.py")
        print("  3. Check blocklists/ directory for output")
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    run_all_tests()
