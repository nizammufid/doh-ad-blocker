#!/usr/bin/env python3
"""
Test Nginx DoH Log Parsing
Demonstrates parsing different nginx DoH log formats
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from log_parser import LogParser
from datetime import datetime


def test_nginx_standard_format():
    """Test parsing standard nginx access log with DNS variables"""
    print("=" * 70)
    print("Test 1: Standard Nginx Access Log Format")
    print("=" * 70)
    
    sample_log = """
192.168.1.100 - - [15/Jan/2024:10:23:45 +0000] "POST /dns-query HTTP/2.0" 200 89 "-" "Mozilla/5.0" "ads.google.com" "A"
192.168.1.100 - - [15/Jan/2024:10:23:46 +0000] "POST /dns-query HTTP/2.0" 200 92 "-" "Mozilla/5.0" "youtube.com" "A"
192.168.1.101 - - [15/Jan/2024:10:23:47 +0000] "POST /dns-query HTTP/2.0" 200 87 "-" "curl/7.68.0" "doubleclick.net" "A"
192.168.1.100 - - [15/Jan/2024:10:23:48 +0000] "POST /dns-query HTTP/2.0" 200 234 "-" "Mozilla/5.0" "r5---sn-5hne6nsr.googlevideo.com" "A"
192.168.1.102 - - [15/Jan/2024:10:23:49 +0000] "POST /dns-query HTTP/2.0" 200 156 "-" "Mozilla/5.0" "pagead2.googlesyndication.com" "A"
"""
    
    # Write to temp file
    temp_log = Path('/tmp/nginx_doh_standard.log')
    temp_log.write_text(sample_log)
    
    # Parse
    parser = LogParser("nginx_doh")
    stats = parser.parse_logs([str(temp_log)], days=30)
    
    print(f"\n✓ Parsed {stats['total_queries']} queries")
    print(f"✓ Found {stats['total_domains']} unique domains\n")
    
    print("Domains detected:")
    for domain, data in sorted(stats['domains'].items()):
        print(f"  • {domain:45s} - {data['count']} queries from {data['unique_clients']} clients")
    
    print("\n✅ Standard format parsing PASSED\n")


def test_nginx_json_format():
    """Test parsing JSON format nginx logs"""
    print("=" * 70)
    print("Test 2: Nginx JSON Log Format")
    print("=" * 70)
    
    sample_log = """
{"time":"2024-01-15T10:23:45+00:00","remote_addr":"192.168.1.100","request":"POST /dns-query HTTP/2.0","status":200,"body_bytes_sent":89,"http_user_agent":"Mozilla/5.0","dns_qname":"ads.google.com","dns_qtype":"A"}
{"time":"2024-01-15T10:23:46+00:00","remote_addr":"192.168.1.100","request":"POST /dns-query HTTP/2.0","status":200,"body_bytes_sent":92,"http_user_agent":"Mozilla/5.0","dns_qname":"youtube.com","dns_qtype":"A"}
{"time":"2024-01-15T10:23:47+00:00","remote_addr":"192.168.1.101","request":"POST /dns-query HTTP/2.0","status":200,"body_bytes_sent":87,"http_user_agent":"curl/7.68.0","dns_qname":"tracking-pixel.adnetwork.com","dns_qtype":"A"}
{"time":"2024-01-15T10:23:48+00:00","remote_addr":"192.168.1.100","request":"POST /dns-query HTTP/2.0","status":200,"body_bytes_sent":234,"http_user_agent":"Mozilla/5.0","dns_qname":"telemetry.mozilla.org","dns_qtype":"A"}
"""
    
    # Write to temp file
    temp_log = Path('/tmp/nginx_doh_json.log')
    temp_log.write_text(sample_log)
    
    # Parse
    parser = LogParser("nginx_doh")
    stats = parser.parse_logs([str(temp_log)], days=30)
    
    print(f"\n✓ Parsed {stats['total_queries']} queries")
    print(f"✓ Found {stats['total_domains']} unique domains\n")
    
    print("Domains detected:")
    for domain, data in sorted(stats['domains'].items()):
        print(f"  • {domain:45s} - {data['count']} queries")
    
    print("\n✅ JSON format parsing PASSED\n")


def test_nginx_custom_format():
    """Test parsing custom DoH log format"""
    print("=" * 70)
    print("Test 3: Custom DoH Log Format")
    print("=" * 70)
    
    sample_log = """
2024-01-15T10:23:45+00:00 192.168.1.100 ads.google.com A 200
2024-01-15T10:23:46+00:00 192.168.1.100 youtube.com A 200
2024-01-15T10:23:47+00:00 192.168.1.101 doubleclick.net A 200
2024-01-15T10:23:48+00:00 192.168.1.100 googlevideo.com A 200
2024-01-15T10:23:49+00:00 192.168.1.102 googleadservices.com A 200
"""
    
    # Write to temp file
    temp_log = Path('/tmp/nginx_doh_custom.log')
    temp_log.write_text(sample_log)
    
    # Parse
    parser = LogParser("nginx_doh")
    stats = parser.parse_logs([str(temp_log)], days=30)
    
    print(f"\n✓ Parsed {stats['total_queries']} queries")
    print(f"✓ Found {stats['total_domains']} unique domains\n")
    
    print("Domains detected:")
    for domain, data in sorted(stats['domains'].items()):
        print(f"  • {domain:45s} - {data['count']} queries")
    
    print("\n✅ Custom format parsing PASSED\n")


def demonstrate_classification():
    """Demonstrate ML classification on parsed domains"""
    print("=" * 70)
    print("Test 4: ML Classification of Nginx DoH Queries")
    print("=" * 70)
    
    from ml_classifier import DomainClassifier
    
    # Parse logs
    sample_log = """
192.168.1.100 - - [15/Jan/2024:10:23:45 +0000] "POST /dns-query HTTP/2.0" 200 89 "-" "Mozilla/5.0" "ads.google.com" "A"
192.168.1.100 - - [15/Jan/2024:10:23:46 +0000] "POST /dns-query HTTP/2.0" 200 92 "-" "Mozilla/5.0" "youtube.com" "A"
192.168.1.101 - - [15/Jan/2024:10:23:47 +0000] "POST /dns-query HTTP/2.0" 200 87 "-" "curl/7.68.0" "doubleclick.net" "A"
192.168.1.100 - - [15/Jan/2024:10:23:48 +0000] "POST /dns-query HTTP/2.0" 200 234 "-" "Mozilla/5.0" "r5---sn-5hne6nsr.googlevideo.com" "A"
192.168.1.102 - - [15/Jan/2024:10:23:49 +0000] "POST /dns-query HTTP/2.0" 200 156 "-" "Mozilla/5.0" "pagead2.googlesyndication.com" "A"
192.168.1.100 - - [15/Jan/2024:10:23:50 +0000] "POST /dns-query HTTP/2.0" 200 145 "-" "Mozilla/5.0" "tracking-analytics.example.com" "A"
192.168.1.100 - - [15/Jan/2024:10:23:51 +0000] "POST /dns-query HTTP/2.0" 200 98 "-" "Mozilla/5.0" "wikipedia.org" "A"
192.168.1.101 - - [15/Jan/2024:10:23:52 +0000] "POST /dns-query HTTP/2.0" 200 102 "-" "Mozilla/5.0" "github.com" "A"
"""
    
    temp_log = Path('/tmp/nginx_doh_classify.log')
    temp_log.write_text(sample_log)
    
    parser = LogParser("nginx_doh")
    stats = parser.parse_logs([str(temp_log)], days=30)
    
    # Classify
    classifier = DomainClassifier()
    
    print("\nClassification Results:")
    print(f"{'Domain':<45} {'Prediction':<10} {'Confidence':<12} {'Queries'}")
    print("-" * 85)
    
    ads_found = []
    
    for domain, data in sorted(stats['domains'].items()):
        is_ad, confidence = classifier.predict(domain, data)
        
        prediction = "🚫 AD" if is_ad else "✅ SAFE"
        
        if is_ad:
            ads_found.append(domain)
        
        print(f"{domain:<45} {prediction:<10} {confidence:>6.1%}       {data['count']}")
    
    print(f"\n✓ Identified {len(ads_found)} ad domains")
    print(f"✓ Total domains analyzed: {len(stats['domains'])}")
    
    if ads_found:
        print("\n📋 Domains to add to blocklist:")
        for domain in ads_found:
            print(f"   • {domain}")
    
    print("\n✅ Classification PASSED\n")


def main():
    print("\n" + "=" * 70)
    print(" Nginx DoH Log Parsing Tests")
    print("=" * 70 + "\n")
    
    try:
        # Test different log formats
        test_nginx_standard_format()
        test_nginx_json_format()
        test_nginx_custom_format()
        
        # Demonstrate classification
        demonstrate_classification()
        
        print("=" * 70)
        print("🎉 All Nginx DoH Tests PASSED!")
        print("=" * 70)
        
        print("\n📝 Your nginx log format is supported!")
        print("\nTo use with your setup:")
        print("1. Update config/config.yaml:")
        print("   format: \"nginx_doh\"")
        print("   log_paths: [\"/var/log/nginx/doh-access.log\"]")
        print("")
        print("2. Run the blocker:")
        print("   python src/main.py")
        print("")
        print("3. See NGINX_DOH_SETUP.md for complete nginx configuration")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
