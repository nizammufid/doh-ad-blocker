# Troubleshooting Guide

## Common Issues and Solutions

### 1. ModuleNotFoundError: No module named 'log_parser'

**Error:**
```
ModuleNotFoundError: No module named 'log_parser'
```

**Cause:** Python can't find the modules in the src directory

**Solutions:**

#### Solution A: Use the wrapper scripts (Easiest)
```bash
# From project root
./run.sh

# Or
python doh_blocker.py

# For training
./scripts/train.sh
```

#### Solution B: Run from src directory
```bash
cd src
python main.py
```

#### Solution C: Set PYTHONPATH manually
```bash
export PYTHONPATH="$(pwd)/src:${PYTHONPATH}"
python src/main.py
```

#### Solution D: Install as package (Advanced)
```bash
pip install -e .
```

---

### 2. Virtual Environment Not Activated

**Error:**
```
bash: venv/bin/activate: No such file or directory
```

**Solution:**
```bash
# Create virtual environment first
python3 -m venv venv

# Then activate
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

---

### 3. Permission Denied: Cannot Read Logs

**Error:**
```
PermissionError: [Errno 13] Permission denied: '/var/log/pihole/pihole.log'
```

**Solutions:**

#### Option A: Add user to log group
```bash
sudo usermod -a -G adm $USER
# Log out and back in for changes to take effect
```

#### Option B: Make logs readable
```bash
sudo chmod 644 /var/log/pihole/pihole.log
```

#### Option C: Run with sudo (not recommended)
```bash
sudo ./run.sh
```

#### Option D: Copy logs to accessible location
```bash
sudo cp /var/log/pihole/pihole.log ~/doh-ad-blocker/data/logs/
# Update config to point to ~/doh-ad-blocker/data/logs/pihole.log
```

---

### 4. No Domains Found / Parsed 0 Queries

**Error:**
```
Parsed 0 queries from 0 unique domains
```

**Debugging Steps:**

#### Step 1: Check if log files exist
```bash
ls -la /var/log/pihole/pihole.log
# or
ls -la /var/log/nginx/doh-queries.log
```

#### Step 2: Check log file has content
```bash
tail -20 /var/log/pihole/pihole.log
```

#### Step 3: Verify log format matches
```bash
# Pi-hole logs should look like:
# Jan 15 10:23:45 dnsmasq[1234]: query[A] example.com from 192.168.1.100

# Nginx logs should look like:
# 192.168.1.100 - - [15/Jan/2024:10:23:45 +0000] "POST /dns-query..." "example.com" "A"
```

#### Step 4: Test parser directly
```bash
cd tests
python test_system.py
```

#### Step 5: Check date range
```yaml
# In config/config.yaml, increase analysis window:
doh_logs:
  analysis_window_days: 30  # Look back 30 days instead of 7
```

#### Step 6: Lower minimum query count
```yaml
doh_logs:
  min_query_count: 1  # Don't filter by frequency
```

---

### 5. scikit-learn Not Installed

**Error:**
```
ModuleNotFoundError: No module named 'sklearn'
```

**Solution:**
```bash
source venv/bin/activate
pip install scikit-learn numpy --break-system-packages
# or without --break-system-packages if in venv
pip install scikit-learn numpy
```

---

### 6. YAML Configuration Errors

**Error:**
```
yaml.scanner.ScannerError: while scanning for the next token
```

**Cause:** Invalid YAML syntax in config.yaml

**Solutions:**

#### Check for common YAML issues:
```yaml
# BAD - tabs instead of spaces
doh_logs:
	format: "pihole"  # ❌ Tab character

# GOOD - spaces only
doh_logs:
  format: "pihole"  # ✅ 2 spaces

# BAD - unquoted special characters
path: /var/log/pihole.log  # May fail if : in path

# GOOD - quoted strings
path: "/var/log/pihole.log"
```

#### Validate YAML:
```bash
python -c "import yaml; yaml.safe_load(open('config/config.yaml'))"
```

---

### 7. GitHub Push Fails

**Error:**
```
Permission denied (publickey)
fatal: Could not read from remote repository
```

**Solutions:**

#### Option A: Use HTTPS instead of SSH
```bash
git remote set-url origin https://github.com/username/repo.git
```

#### Option B: Setup SSH key
```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
cat ~/.ssh/id_ed25519.pub
# Add to GitHub: Settings → SSH Keys
```

#### Option C: Use personal access token
```bash
# Create token at: github.com → Settings → Developer settings → Personal access tokens
git remote set-url origin https://USERNAME:TOKEN@github.com/username/repo.git
```

---

### 8. No New Domains Found

**Output:**
```
Identified 0 new ad domains (high confidence)
```

**Possible Causes:**

1. **All ads already in known list**
   - Solution: Check `data/known_ads.txt` - if it has 100k+ domains, most are already known
   
2. **Confidence threshold too high**
   ```yaml
   ml:
     confidence_threshold: 0.85  # Try lowering to 0.70
   ```

3. **Not enough DNS traffic**
   - Solution: Wait for more queries to accumulate (run again after a few days)

4. **Mostly legitimate traffic**
   - This is good! Means your network isn't hitting many ad domains

---

### 9. YouTube Videos Not Loading

**Issue:** After applying blocklists, YouTube videos won't play

**Solution:**

#### Check whitelist in config.yaml:
```yaml
blocklist:
  whitelist:
    - "googlevideo.com"  # REQUIRED for videos
    - "ytimg.com"        # REQUIRED for thumbnails  
    - "youtube.com"      # REQUIRED for site
    - "gstatic.com"      # REQUIRED for fonts/scripts
```

#### Remove aggressive blocking:
```yaml
youtube:
  aggressive_mode: false  # Change to false
```

#### Check your Pi-hole whitelist:
```bash
# Add to Pi-hole whitelist
pihole -w googlevideo.com ytimg.com gstatic.com
```

---

### 10. Model Training Takes Too Long

**Issue:** Training hangs or takes hours

**Solutions:**

#### Use smaller dataset:
```bash
# Limit training data
head -10000 data/known_ads.txt > data/known_ads_small.txt
# Update config to use known_ads_small.txt
```

#### Use simpler model:
```yaml
ml:
  model_type: "random_forest"  # Faster than gradient_boosting
```

#### Skip ML entirely (use rules only):
```yaml
ml:
  confidence_threshold: 0.0  # Disable ML scoring
```

---

### 11. High False Positive Rate

**Issue:** Legitimate sites being blocked

**Solutions:**

#### Increase confidence threshold:
```yaml
ml:
  confidence_threshold: 0.90  # More conservative (was 0.85)
```

#### Check manual review list:
```bash
cat logs/manual_review.txt
# Add safe domains to whitelist
```

#### Add to whitelist:
```yaml
blocklist:
  whitelist:
    - "your-safe-domain.com"
    - "another-safe-site.com"
```

---

### 12. Cron Job Not Running

**Issue:** Automation not working

**Debugging:**

#### Check cron is running:
```bash
systemctl status cron
```

#### View cron logs:
```bash
grep CRON /var/log/syslog
```

#### Test cron command manually:
```bash
# Copy command from crontab
cd /path/to/doh-ad-blocker && ./run.sh
```

#### Check cron user permissions:
```bash
# Run as same user as cron
sudo -u $USER /path/to/doh-ad-blocker/run.sh
```

---

## Quick Diagnostics

Run this to check your setup:

```bash
#!/bin/bash
echo "=== DoH Ad Blocker Diagnostics ==="

echo -e "\n1. Python version:"
python3 --version

echo -e "\n2. Virtual environment:"
if [ -d "venv" ]; then
    echo "✓ venv exists"
else
    echo "✗ venv missing - run ./setup.sh"
fi

echo -e "\n3. Required packages:"
python3 -c "import yaml; print('✓ pyyaml')" 2>/dev/null || echo "✗ pyyaml missing"
python3 -c "import sklearn; print('✓ scikit-learn')" 2>/dev/null || echo "✗ scikit-learn missing"

echo -e "\n4. Log files:"
if [ -f "/var/log/pihole/pihole.log" ]; then
    echo "✓ Pi-hole log exists"
    echo "  Lines: $(wc -l < /var/log/pihole/pihole.log)"
else
    echo "✗ Pi-hole log not found"
fi

echo -e "\n5. Config file:"
if [ -f "config/config.yaml" ]; then
    echo "✓ config.yaml exists"
else
    echo "✗ config.yaml missing"
fi

echo -e "\n6. Training data:"
if [ -f "data/known_ads.txt" ]; then
    echo "✓ known_ads.txt exists"
    echo "  Domains: $(wc -l < data/known_ads.txt)"
else
    echo "✗ known_ads.txt missing"
fi

echo -e "\n7. Permissions:"
if [ -r "/var/log/pihole/pihole.log" ]; then
    echo "✓ Can read logs"
else
    echo "✗ Cannot read logs - check permissions"
fi

echo -e "\n=== End Diagnostics ==="
```

Save as `diagnostics.sh`, run with `bash diagnostics.sh`

---

## Still Having Issues?

### Enable Debug Logging

Edit `config/config.yaml`:
```yaml
logging:
  level: "DEBUG"  # Changed from INFO
```

Then check detailed logs:
```bash
tail -100 logs/doh-blocker.log
```

### Test Individual Components

```bash
# Test log parser
python -c "
import sys
sys.path.insert(0, 'src')
from log_parser import LogParser
parser = LogParser('pihole')
stats = parser.parse_logs(['/var/log/pihole/pihole.log'], days=7)
print(f'Found {len(stats[\"domains\"])} domains')
"

# Test classifier
python -c "
import sys
sys.path.insert(0, 'src')
from ml_classifier import DomainClassifier
classifier = DomainClassifier()
is_ad, conf = classifier.predict('ads.google.com')
print(f'ads.google.com: {is_ad} ({conf:.1%})')
"
```

### Get Help

Include this info when asking for help:
```bash
python3 --version
cat /etc/os-release | grep PRETTY_NAME
ls -la /var/log/pihole/pihole.log
head -5 /var/log/pihole/pihole.log
cat logs/doh-blocker.log | tail -50
```
