#!/bin/bash
# DoH Ad Blocker - Run Script

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Set Python path to include src directory
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH}"

# Run the main script
cd src
python main.py "$@"
