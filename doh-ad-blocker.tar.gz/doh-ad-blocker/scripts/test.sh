#!/bin/bash
# DoH Ad Blocker - Test Script

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Set Python path
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH}"

# Run tests
cd tests
python test_system.py "$@"
