#!/bin/bash
# DoH Ad Blocker - Training Script

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Set Python path
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH}"

# Run training
cd src
python -c "
from main import DoHAdBlocker

print('Initializing DoH Ad Blocker...')
blocker = DoHAdBlocker()

print('Loading training data...')
blocker.load_training_data()

print('Parsing logs...')
stats = blocker.parse_logs()

print('Training model...')
blocker.train_model(stats)

print('Training complete!')
"
