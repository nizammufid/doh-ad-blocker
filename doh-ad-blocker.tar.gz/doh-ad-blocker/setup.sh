#!/bin/bash
# DoH Ad Blocker - Installation Script

set -e

echo "=================================="
echo "DoH Ad Blocker - Setup"
echo "=================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    echo -e "${YELLOW}Warning: Running as root. Consider using a regular user.${NC}"
fi

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
else
    OS=$(uname -s)
fi

echo "Detected OS: $OS"

# Install Python and dependencies
echo -e "\n${GREEN}Installing Python dependencies...${NC}"

if command -v apt-get &> /dev/null; then
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip python3-venv git
elif command -v yum &> /dev/null; then
    sudo yum install -y python3 python3-pip git
elif command -v brew &> /dev/null; then
    brew install python3 git
else
    echo -e "${RED}Could not detect package manager. Please install Python 3.8+ and pip manually.${NC}"
    exit 1
fi

# Create virtual environment
echo -e "\n${GREEN}Creating virtual environment...${NC}"
python3 -m venv venv
source venv/bin/activate

# Install Python packages
echo -e "\n${GREEN}Installing Python packages...${NC}"
pip install --upgrade pip
pip install -r requirements.txt

# Create necessary directories
echo -e "\n${GREEN}Creating directories...${NC}"
mkdir -p data/{logs,known_ads,known_safe}
mkdir -p logs
mkdir -p models
mkdir -p blocklists
mkdir -p scripts

# Download initial blocklists for training
echo -e "\n${GREEN}Downloading initial training data...${NC}"

# Steven Black's hosts file (popular blocklist)
curl -s -o data/stevenblack-hosts.txt \
    https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts

# Extract domains for training
grep "^0.0.0.0" data/stevenblack-hosts.txt | awk '{print $2}' > data/known_ads.txt

echo -e "${GREEN}Downloaded $(wc -l < data/known_ads.txt) known ad domains${NC}"

# Create known safe domains list
cat > data/known_safe.txt << 'EOF'
google.com
youtube.com
facebook.com
amazon.com
wikipedia.org
reddit.com
twitter.com
github.com
stackoverflow.com
linkedin.com
microsoft.com
apple.com
netflix.com
cloudflare.com
mozilla.org
ubuntu.com
debian.org
archlinux.org
kernel.org
python.org
npmjs.com
docker.com
kubernetes.io
EOF

echo -e "${GREEN}Created known safe domains list${NC}"

# Setup configuration
echo -e "\n${GREEN}Configuring system...${NC}"

# Detect Pi-hole or AdGuard Home
PIHOLE_LOG="/var/log/pihole/pihole.log"
ADGUARD_LOG="/var/log/AdGuardHome/querylog.json"

if [ -f "$PIHOLE_LOG" ]; then
    echo -e "${GREEN}✓ Detected Pi-hole installation${NC}"
    LOG_FORMAT="pihole"
    LOG_PATH="$PIHOLE_LOG"
elif [ -f "$ADGUARD_LOG" ]; then
    echo -e "${GREEN}✓ Detected AdGuard Home installation${NC}"
    LOG_FORMAT="adguard"
    LOG_PATH="$ADGUARD_LOG"
else
    echo -e "${YELLOW}⚠ Could not detect Pi-hole or AdGuard Home${NC}"
    echo -e "${YELLOW}  Please update config/config.yaml with your log paths${NC}"
    LOG_FORMAT="pihole"
    LOG_PATH="/var/log/pihole/pihole.log"
fi

# Update config with detected settings
sed -i "s|format: \"pihole\"|format: \"$LOG_FORMAT\"|" config/config.yaml
sed -i "s|/var/log/pihole/pihole.log|$LOG_PATH|" config/config.yaml

# Create systemd service for automation (optional)
echo -e "\n${YELLOW}Would you like to setup automated daily updates? (y/n)${NC}"
read -r SETUP_AUTO

if [ "$SETUP_AUTO" = "y" ]; then
    cat > /tmp/doh-ad-blocker.service << EOF
[Unit]
Description=DoH Ad Blocker - Automated Blocklist Updater
After=network.target

[Service]
Type=oneshot
User=$USER
WorkingDirectory=$(pwd)
ExecStart=$(pwd)/venv/bin/python $(pwd)/src/main.py
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    cat > /tmp/doh-ad-blocker.timer << EOF
[Unit]
Description=DoH Ad Blocker Daily Update Timer

[Timer]
OnCalendar=daily
OnBootSec=10min
Persistent=true

[Install]
WantedBy=timers.target
EOF

    sudo mv /tmp/doh-ad-blocker.service /etc/systemd/system/
    sudo mv /tmp/doh-ad-blocker.timer /etc/systemd/system/
    
    sudo systemctl daemon-reload
    sudo systemctl enable doh-ad-blocker.timer
    sudo systemctl start doh-ad-blocker.timer
    
    echo -e "${GREEN}✓ Automated updates configured (runs daily at 2 AM)${NC}"
    echo -e "  Check status: ${YELLOW}systemctl status doh-ad-blocker.timer${NC}"
fi

# Create quick-start scripts
cat > scripts/run.sh << 'EOF'
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"
source venv/bin/activate
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH}"
cd src
python main.py "$@"
EOF

cat > scripts/train.sh << 'EOF'
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"
source venv/bin/activate
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH}"
cd src
python -c "
from main import DoHAdBlocker
blocker = DoHAdBlocker()
blocker.load_training_data()
stats = blocker.parse_logs()
blocker.train_model(stats)
"
EOF

chmod +x scripts/*.sh

# Also create main run script
cat > run.sh << 'EOF'
#!/bin/bash
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"
if [ -d "venv" ]; then source venv/bin/activate; fi
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH}"
cd src
python main.py "$@"
EOF

chmod +x run.sh

# Setup Git repository
if [ ! -d .git ]; then
    echo -e "\n${YELLOW}Would you like to initialize a Git repository? (y/n)${NC}"
    read -r INIT_GIT
    
    if [ "$INIT_GIT" = "y" ]; then
        git init
        
        # Create .gitignore
        cat > .gitignore << 'EOF'
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
env/

# Logs
logs/*.log
*.log

# Models
models/*.pkl

# Local config
config/local.yaml

# Data
data/logs/

# OS
.DS_Store
Thumbs.db
EOF
        
        echo -e "${GREEN}✓ Git repository initialized${NC}"
        echo -e "  Next steps:"
        echo -e "    1. Create a GitHub repository"
        echo -e "    2. git remote add origin <your-repo-url>"
        echo -e "    3. git add ."
        echo -e "    4. git commit -m 'Initial commit'"
        echo -e "    5. git push -u origin main"
    fi
fi

echo -e "\n${GREEN}=================================="
echo "Installation Complete!"
echo -e "==================================${NC}"

echo -e "\n${YELLOW}Next Steps:${NC}"
echo "1. Edit config/config.yaml with your settings"
echo "2. Update GitHub credentials:"
echo "   - Set GITHUB_TOKEN environment variable"
echo "   - Or use GitHub Actions secrets"
echo ""
echo "3. Run initial training:"
echo "   ${GREEN}bash scripts/train.sh${NC}"
echo ""
echo "4. Run the blocker:"
echo "   ${GREEN}bash scripts/run.sh${NC}"
echo ""
echo "5. For manual execution:"
echo "   ${GREEN}source venv/bin/activate${NC}"
echo "   ${GREEN}python src/main.py${NC}"

echo -e "\n${YELLOW}Configuration Files:${NC}"
echo "  - config/config.yaml         Main configuration"
echo "  - data/known_ads.txt         Known ad domains (training)"
echo "  - data/known_safe.txt        Known safe domains (training)"
echo ""
echo -e "${YELLOW}Generated Blocklists:${NC}"
echo "  - blocklists/hosts.txt       Hosts file format"
echo "  - blocklists/domains.txt     Plain domain list"
echo "  - blocklists/adblock.txt     AdBlock Plus format"
echo "  - blocklists/dnsmasq.conf    Dnsmasq format"
echo "  - blocklists/unbound.conf    Unbound format"

echo -e "\n${GREEN}Happy ad blocking! 🚫📢${NC}"
