#!/usr/bin/env python3
"""
DoH Ad Blocker - Main Entry Point
Can be run from any directory
"""

import sys
import os
from pathlib import Path

# Add src directory to Python path
PROJECT_DIR = Path(__file__).parent.resolve()
SRC_DIR = PROJECT_DIR / "src"
sys.path.insert(0, str(SRC_DIR))

# Change to project directory
os.chdir(PROJECT_DIR)

# Now import and run
from main import main

if __name__ == "__main__":
    sys.exit(main())
