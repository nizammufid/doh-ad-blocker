#!/bin/bash
# DoH Ad Blocker - Main Run Script
# Usage: ./run.sh [--dry-run] [--config path/to/config.yaml]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get project directory
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

echo -e "${GREEN}DoH Ad Blocker${NC}"
echo "================="

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}Virtual environment not found. Run ./setup.sh first.${NC}"
    exit 1
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Check if required packages are installed
if ! python -c "import yaml" 2>/dev/null; then
    echo -e "${YELLOW}Installing required packages...${NC}"
    pip install -r requirements.txt --break-system-packages 2>/dev/null || pip install -r requirements.txt
fi

# Set Python path
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH}"

# Run the main script
echo -e "${GREEN}Running DoH Ad Blocker...${NC}"
echo ""

cd src
python main.py "$@"

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ Completed successfully!${NC}"
    echo ""
    echo "Generated blocklists:"
    ls -lh ../blocklists/ 2>/dev/null | grep -E '\.(txt|conf)$' || echo "  (none yet)"
else
    echo ""
    echo -e "${RED}❌ Failed with exit code $EXIT_CODE${NC}"
    echo "Check logs/doh-blocker.log for details"
fi

exit $EXIT_CODE
