#!/usr/bin/env python3
"""
DoH Log Parser - Extracts DNS queries from various log formats
Supports: Pi-hole, AdGuard Home, Unbound, BIND, Cloudflared, DNSCrypt-Proxy
"""

import re
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Optional, Set
from collections import defaultdict, Counter
import gzip
import logging

logger = logging.getLogger(__name__)


class LogParser:
    """Universal DoH/DNS log parser"""
    
    def __init__(self, log_format: str = "pihole"):
        self.log_format = log_format.lower()
        self.queries = defaultdict(lambda: {
            'count': 0,
            'timestamps': [],
            'client_ips': set(),
            'query_types': Counter(),
            'response_codes': Counter(),
            'blocked': False
        })
    
    def parse_logs(self, log_paths: List[str], days: int = 7) -> Dict:
        """Parse multiple log files"""
        cutoff_time = datetime.now() - timedelta(days=days)
        
        for log_path in log_paths:
            path = Path(log_path)
            if not path.exists():
                logger.warning(f"Log file not found: {log_path}")
                continue
            
            logger.info(f"Parsing {log_path}...")
            
            # Handle compressed logs
            if path.suffix == '.gz':
                with gzip.open(path, 'rt') as f:
                    self._parse_file(f, cutoff_time)
            else:
                with open(path, 'r') as f:
                    self._parse_file(f, cutoff_time)
        
        return self._get_statistics()
    
    def _parse_file(self, file_handle, cutoff_time):
        """Parse individual log file based on format"""
        parser_method = getattr(self, f'_parse_{self.log_format}', None)
        
        if not parser_method:
            raise ValueError(f"Unsupported log format: {self.log_format}")
        
        for line in file_handle:
            try:
                parser_method(line.strip(), cutoff_time)
            except Exception as e:
                logger.debug(f"Failed to parse line: {e}")
                continue
    
    def _parse_pihole(self, line: str, cutoff_time: datetime):
        """Parse Pi-hole logs (dnsmasq format)
        Example: Jan 15 10:23:45 dnsmasq[1234]: query[A] ads.example.com from 192.168.1.100
        """
        # Query pattern
        query_pattern = r'(\w+ \d+ \d+:\d+:\d+).*query\[(\w+)\]\s+(\S+)\s+from\s+(\S+)'
        # Reply pattern (to check if blocked)
        reply_pattern = r'(\w+ \d+ \d+:\d+:\d+).*reply\s+(\S+)\s+is\s+(\S+)'
        # Blocked pattern
        blocked_pattern = r'(\w+ \d+ \d+:\d+:\d+).*\s+(\S+)\s+is\s+(0\.0\.0\.0|NXDOMAIN|\:\:)'
        
        # Parse query
        match = re.search(query_pattern, line)
        if match:
            timestamp_str, query_type, domain, client_ip = match.groups()
            timestamp = self._parse_timestamp(timestamp_str)
            
            if timestamp >= cutoff_time:
                self._add_query(domain, timestamp, client_ip, query_type)
        
        # Check if blocked
        match = re.search(blocked_pattern, line)
        if match:
            timestamp_str, domain, _ = match.groups()
            self.queries[domain]['blocked'] = True
    
    def _parse_adguard(self, line: str, cutoff_time: datetime):
        """Parse AdGuard Home logs (JSON format)
        Example: {"QH":"ads.example.com","QT":"A","QC":"IN","CP":"192.168.1.100","Answer":"Blocked"}
        """
        try:
            log_entry = json.loads(line)
            
            # Extract fields
            domain = log_entry.get('QH', '')  # Query Host
            query_type = log_entry.get('QT', 'A')  # Query Type
            client_ip = log_entry.get('CP', '')  # Client Port/IP
            answer = log_entry.get('Answer', '')
            timestamp_str = log_entry.get('Time', '')
            
            if not domain:
                return
            
            # Parse timestamp
            if timestamp_str:
                timestamp = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
            else:
                timestamp = datetime.now()
            
            if timestamp >= cutoff_time:
                self._add_query(domain, timestamp, client_ip, query_type)
                
                # Check if blocked
                if 'Blocked' in answer or 'FilteredBlackList' in answer:
                    self.queries[domain]['blocked'] = True
        
        except json.JSONDecodeError:
            pass
    
    def _parse_unbound(self, line: str, cutoff_time: datetime):
        """Parse Unbound logs
        Example: [1234567890] unbound[1234:0] info: 192.168.1.100 ads.example.com. A IN
        """
        pattern = r'\[(\d+)\].*info:\s+(\S+)\s+(\S+)\.\s+(\w+)\s+'
        match = re.search(pattern, line)
        
        if match:
            timestamp_unix, client_ip, domain, query_type = match.groups()
            timestamp = datetime.fromtimestamp(int(timestamp_unix))
            
            if timestamp >= cutoff_time:
                domain = domain.rstrip('.')
                self._add_query(domain, timestamp, client_ip, query_type)
    
    def _parse_bind(self, line: str, cutoff_time: datetime):
        """Parse BIND query logs
        Example: 15-Jan-2024 10:23:45.123 queries: info: client @0x7f8a 192.168.1.100#12345 (ads.example.com): query: ads.example.com IN A
        """
        pattern = r'(\d+-\w+-\d+ \d+:\d+:\d+).*client.*?(\S+)#\d+\s+\(([^)]+)\).*query:\s+(\S+)\s+IN\s+(\w+)'
        match = re.search(pattern, line)
        
        if match:
            timestamp_str, client_ip, _, domain, query_type = match.groups()
            timestamp = datetime.strptime(timestamp_str, '%d-%b-%Y %H:%M:%S')
            
            if timestamp >= cutoff_time:
                self._add_query(domain, timestamp, client_ip, query_type)
    
    def _parse_cloudflared(self, line: str, cutoff_time: datetime):
        """Parse Cloudflared DoH proxy logs
        Example: 2024/01/15 10:23:45 INF Received query name=ads.example.com type=A
        """
        pattern = r'(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}).*name=(\S+)\s+type=(\w+)'
        match = re.search(pattern, line)
        
        if match:
            timestamp_str, domain, query_type = match.groups()
            timestamp = datetime.strptime(timestamp_str, '%Y/%m/%d %H:%M:%S')
            
            if timestamp >= cutoff_time:
                self._add_query(domain, timestamp, 'unknown', query_type)
    
    def _parse_dnscrypt(self, line: str, cutoff_time: datetime):
        """Parse DNSCrypt-proxy logs
        Example: [2024-01-15 10:23:45] [NOTICE] ads.example.com A
        """
        pattern = r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\].*\]\s+(\S+)\s+(\w+)'
        match = re.search(pattern, line)
        
        if match:
            timestamp_str, domain, query_type = match.groups()
            timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
            
            if timestamp >= cutoff_time:
                self._add_query(domain, timestamp, 'unknown', query_type)
    
    def _parse_timestamp(self, timestamp_str: str) -> datetime:
        """Parse various timestamp formats"""
        # Try common formats
        formats = [
            '%b %d %H:%M:%S',  # Jan 15 10:23:45
            '%Y-%m-%d %H:%M:%S',
            '%d-%b-%Y %H:%M:%S',
            '%Y/%m/%d %H:%M:%S'
        ]
        
        for fmt in formats:
            try:
                dt = datetime.strptime(timestamp_str, fmt)
                # Add current year if not present
                if dt.year == 1900:
                    dt = dt.replace(year=datetime.now().year)
                return dt
            except ValueError:
                continue
        
        # Fallback to current time
        return datetime.now()
    
    def _add_query(self, domain: str, timestamp: datetime, client_ip: str, query_type: str):
        """Add a query to the statistics"""
        domain = domain.lower().rstrip('.')
        
        # Skip invalid domains
        if not domain or domain == 'localhost' or domain.startswith('.'):
            return
        
        self.queries[domain]['count'] += 1
        self.queries[domain]['timestamps'].append(timestamp)
        self.queries[domain]['client_ips'].add(client_ip)
        self.queries[domain]['query_types'][query_type] += 1
    
    def _get_statistics(self) -> Dict:
        """Get parsed statistics"""
        stats = {
            'total_domains': len(self.queries),
            'total_queries': sum(q['count'] for q in self.queries.values()),
            'domains': {}
        }
        
        for domain, data in self.queries.items():
            stats['domains'][domain] = {
                'count': data['count'],
                'unique_clients': len(data['client_ips']),
                'query_types': dict(data['query_types']),
                'blocked': data['blocked'],
                'first_seen': min(data['timestamps']) if data['timestamps'] else None,
                'last_seen': max(data['timestamps']) if data['timestamps'] else None,
                'timestamps': data['timestamps']
            }
        
        return stats
    
    def get_top_domains(self, n: int = 100, min_count: int = 1) -> List[tuple]:
        """Get top N most queried domains"""
        filtered = {
            domain: data for domain, data in self.queries.items()
            if data['count'] >= min_count
        }
        
        sorted_domains = sorted(
            filtered.items(),
            key=lambda x: x[1]['count'],
            reverse=True
        )
        
        return [(domain, data['count']) for domain, data in sorted_domains[:n]]


if __name__ == "__main__":
    # Quick test
    logging.basicConfig(level=logging.INFO)
    
    parser = LogParser("pihole")
    
    # Example usage
    print("DoH Log Parser initialized")
    print("Supported formats: pihole, adguard, unbound, bind, cloudflared, dnscrypt")
